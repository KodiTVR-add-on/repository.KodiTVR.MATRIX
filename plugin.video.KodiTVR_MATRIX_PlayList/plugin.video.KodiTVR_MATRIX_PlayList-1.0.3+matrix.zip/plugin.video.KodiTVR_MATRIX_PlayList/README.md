# plugin.video.KodiTVR_MATRIX_PlayList
Taking ownership of plugin.video.KodiTVR_MATRIX_PlayList previously owned Mod by KodiTVR
See: https://github.com/KodiTVR-add-on/repository.KodiTVR.MATRIX
